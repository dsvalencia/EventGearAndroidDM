package com.example.raque.eventgear;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.ContextThemeWrapper;

import java.util.Calendar;

/**
 * Created by Sanchez on 12/12/16.
 */
public class DataBase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Events";
    private static final int DATABASE_VERSION = 2;

    public DataBase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.beginTransaction();
        try {
//            db.execSQL("DELETE TABLE Events");


            db.execSQL("CREATE TABLE IF NOT EXISTS eventos("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "name string(255) NOT NULL,"
                    + "descripcion string(1000) NOT NULL,"
                    + "categoria string(30),"
                    + "date date NOT NULL"
                    + ")");

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        Log.w(DataBase.class.getName(), "actualizando base de datos" + i + "a la versión" + i1);
        sqLiteDatabase.beginTransaction();
        try {
            sqLiteDatabase.execSQL("DROP DATABASE IF EXISTS Events");
            sqLiteDatabase.setTransactionSuccessful();
        } finally {
            sqLiteDatabase.endTransaction();
        }
        this.onCreate(sqLiteDatabase);
    }

    public  Cursor consultaCategoria(DataBase dataB, String category) {
        SQLiteDatabase db = dataB.getReadableDatabase();

        String query = "SELECT * FROM eventos"; //WHERE categoria LIKE "+"%"+category+"%";
        Cursor eventCursor = db.rawQuery(query, null);
        return eventCursor;
    }

    public  Cursor consultaTodos(DataBase dataB) {
        SQLiteDatabase db = dataB.getReadableDatabase();
        String query = "SELECT * FROM eventos";
        Cursor eventCursor = db.rawQuery(query, null);
        return eventCursor;
    }

    public Cursor consultaTodos(DataBase dataB, String date) {
        SQLiteDatabase db = dataB.getReadableDatabase();
        String finalDate= date.substring(0,10);
        finalDate+="23:59:59";
       String query = "SELECT * FROM eventos WHERE date >=Datetime('" + date + "') AND date <=Datetime('" + finalDate + "')";
        Cursor eventCursor = db.rawQuery(query, null);
        return eventCursor;
    }

    public void deleteElemento(DataBase dataB, String name) {
        SQLiteDatabase db = dataB.getWritableDatabase();
        db.execSQL("DELETE * FROM eventos WHERE name <> ?" , new String[]{name});
    }
    public void addElemento(DataBase dataB, Evento event){
        SQLiteDatabase db = dataB.getWritableDatabase();
        db.beginTransaction();
        ContentValues values= new ContentValues();
        //values.put("id","eee");
        values.put("name",event.getName());
        values.put("descripcion",event.getDescripcion());
        values.put("categoria",event.getCategoria());
        values.put("date",event.getDate());
        try{
        long events = db.insert("eventos", null,values);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }

    }
}